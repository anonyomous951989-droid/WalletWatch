
const BillingPlanCard = () => {
  return (
    <div>BillingPlanCard</div>
  )
}

export default BillingPlanCard